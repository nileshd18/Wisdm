import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-firstwithtabs',
  templateUrl: './firstwithtabs.page.html',
  styleUrls: ['./firstwithtabs.page.scss'],
})
export class FirstwithtabsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
