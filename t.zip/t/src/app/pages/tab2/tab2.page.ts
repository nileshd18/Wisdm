import { Component, OnInit } from '@angular/core';
import { Test1Service } from 'src/app/test1.service';

@Component({
  selector: 'app-tab2',
  templateUrl: './tab2.page.html',
  styleUrls: ['./tab2.page.scss'],
})
export class Tab2Page implements OnInit {
  public searchTerm: string = "";
  public items: any;
  constructor(private testservice1: Test1Service) { }

  ngOnInit() {
    this.setFilteredItems();
  }

  setFilteredItems() {
    this.items = this.testservice1.filterItems(this.searchTerm);
  }

}
