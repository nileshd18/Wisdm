import { Component, OnInit } from '@angular/core';
import { TestService } from 'src/app/test.service';

@Component({
  selector: 'app-second',
  templateUrl: './second.page.html',
  styleUrls: ['./second.page.scss'],
})
export class SecondPage {
  public detailsdata: any = [];
  constructor(private testservice: TestService) {
    this.gettingData();
  }
  gettingData() {
    this.testservice.getdata()
      .subscribe((data) => {
        this.detailsdata = data;
        console.log(this.detailsdata);
        console.log(JSON.stringify(this.detailsdata));
      });
  }
}


