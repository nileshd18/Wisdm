import { Component, OnInit } from '@angular/core';
import { TestService } from 'src/app/test.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-tab1',
  templateUrl: './tab1.page.html',
  styleUrls: ['./tab1.page.scss'],
})
export class Tab1Page {

  public datalist: any = [];
  constructor(private testservice: TestService,private router:Router) {
    this.gettingData();

  }
  gettingData() {
    this.testservice.getdata()
      .subscribe((data) => {
        this.datalist = data;
        console.log(this.datalist);
        console.log(JSON.stringify(this.datalist));
      });
  }

  open(){
    // this.router.navigate(['login']);
    this.router.navigateByUrl('second');
  }
}