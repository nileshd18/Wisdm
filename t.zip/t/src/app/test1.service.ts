import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class Test1Service {
  public items: any = [];
   constructor(private http: HttpClient) { 
    this.items = [
      { fruits: "mango" },
      { fruits: "banana" },
      { fruits: "grapes" },
      { fruits: "apple" },
      { fruits: "pinapple" },
      { fruits: "lemon" }
    ];
   }

  filterItems(searchTerm) {
    return this.items.filter(item => {
      return item.fruits.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    });
  }
}
