import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  private url: string = "https://deckofcardsapi.com/api/deck/h2glbyeihabx/draw/?count=2";
  constructor(private http: HttpClient) { }
  getdata() {
    return this.http.get(this.url);
  }
}
